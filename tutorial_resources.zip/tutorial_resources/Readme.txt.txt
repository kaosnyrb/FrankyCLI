For use with https://www.nexusmods.com/starfield/articles/458

Data folder goes in the Starfield Data folder.

start_template.blend is just opened in blender.
